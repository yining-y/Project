package com.yyn.servlet;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

public class ImgServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        this.doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse response)
            throws ServletException, IOException {
        
        String name =  req.getParameter("PicName");
        
        response.setContentType("image/jpg");
        response.setCharacterEncoding("utf-8");
        
        // 创建FTPClient对象
        FTPClient ftp = new FTPClient();
        try {
            // 连接FTP服务器
            // 如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
            ftp.connect("172.18.12.14", 6095);
            // 登录ftp
            ftp.login("root", "123456");
             // 转到指定ftp目录
            ftp.changeWorkingDirectory("/CAS/LXJT");
            
            ftp.setFileType(FTP.BINARY_FILE_TYPE);  
            // 列出该目录下所有文件
            FTPFile[] fs = ftp.listFiles();
            // 遍历所有文件，找到指定的文件
            for (FTPFile ff : fs) {
                if (ff.getName().equals(name)) {
                    // 根据绝对路径初始化文件
                    InputStream fis = ftp.retrieveFileStream(ff.getName());
                    byte[] b = new byte[1024];    
                    int len = 0;    
                    OutputStream out = response.getOutputStream();
                    while ((len = fis.read(b)) != -1) {    
                        out.write(b, 0, len);    
                        out.flush();    
                    }
                    out.close();
                }
            }
            // 退出ftp
            ftp.logout();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (ftp.isConnected()) {
                try {
                    ftp.disconnect();
                } catch (IOException ioe) {
                }
            }
        }
    }
}